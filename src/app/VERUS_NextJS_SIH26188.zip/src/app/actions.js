'use server';

import { createClient } from '@supabase/supabase-js';
import { revalidatePath } from 'next/cache';

function getSupabaseAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !key) {
    throw new Error(
      'Supabase environment variables are missing. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.'
    );
  }

  return createClient(url, key);
}

export async function createPost(formData) {
  const title = String(formData.get('title') ?? '').trim();
  const content = String(formData.get('content') ?? '').trim();

  if (!title) throw new Error('Title is required.');

  const supabase = getSupabaseAdminClient();

  const { error } = await supabase
    .from('posts')
    .insert([{ title, content }]);

  if (error) {
    throw new Error(`Supabase posts insert failed: ${error.message}`);
  }

  revalidatePath('/');
}
