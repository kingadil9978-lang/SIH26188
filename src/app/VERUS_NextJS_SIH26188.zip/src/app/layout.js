import './globals.css';

export const metadata = {
  title: 'VERUS — AI-Based Fake Identity & Document Screening System',
  description: 'SIH26188 — AI-based fake identity and document screening system.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
